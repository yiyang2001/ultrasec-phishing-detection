# phishing-detection-plugin

This lightweight Chrome plugin detects phishing websites and alerts the user. It is designed with privacy in mind, so that user browsing data is not collected for classification. The classification is performed on the client side via a one-time download of the classifier model.
